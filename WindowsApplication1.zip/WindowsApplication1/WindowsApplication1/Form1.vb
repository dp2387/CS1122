﻿Public Class Form1
    Private Sub TextBox1_TabIndexChanged(sender As Object, e As EventArgs) Handles TextBox1.TabIndexChanged
        TextBox1.BackColor = Color.LightGreen
        TextBox2.BackColor = Color.DarkGray
        TextBox3.BackColor = Color.DarkGray
    End Sub

    Private Sub TextBox2_TabIndexChanged(sender As Object, e As EventArgs) Handles TextBox2.TabIndexChanged
        TextBox1.BackColor = Color.DarkGray
        TextBox2.BackColor = Color.Yellow
        TextBox3.BackColor = Color.DarkGray
    End Sub

    Private Sub TextBox3_TabIndexChanged(sender As Object, e As EventArgs) Handles TextBox3.TabIndexChanged
        TextBox1.BackColor = Color.DarkGray
        TextBox2.BackColor = Color.DarkGray
        TextBox3.BackColor = Color.Red
    End Sub
End Class
